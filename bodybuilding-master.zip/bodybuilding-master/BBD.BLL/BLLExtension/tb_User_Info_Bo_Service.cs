﻿using BBD.IBLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBD.BLL
{
    public partial class tb_User_Info_Bo_Service : Itb_User_Info_Bo_BLL
    {
    }
}
