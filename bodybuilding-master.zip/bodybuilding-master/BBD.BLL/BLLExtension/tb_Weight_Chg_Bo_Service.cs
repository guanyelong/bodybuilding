﻿using BBD.IBLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBD.BLL
{
    public partial class tb_Weight_Chg_Bo_Service : Itb_Weight_Chg_Bo_BLL
    {
    }
}
