﻿using BBD.IBLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBD.BLL
{
    public partial class tb_Serv_Info_Bo_Service : Itb_Serv_Info_Bo_BLL
    {

    }
}
