﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBD.Models
{
    public partial class tb_Sys_UserInfo
    {
        public string uDepName { get; set; }
        public string uDepNum { get; set; }

        public string CityName { get; set; }
    }
}
