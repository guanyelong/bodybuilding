﻿using BBD.IBLL;
using BBD.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBD.BLL
{
    public partial class tb_Hei_Wei_Bo_Service : Itb_Hei_Wei_Bo_BLL
    {
        
    }
}
