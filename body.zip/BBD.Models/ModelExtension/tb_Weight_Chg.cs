﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBD.Models
{
    public partial class tb_Weight_Chg
    {
        public string uName { get; set; }
        public string Mobile { get; set; }
    }
}
