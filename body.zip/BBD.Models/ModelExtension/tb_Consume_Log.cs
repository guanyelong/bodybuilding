﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBD.Models
{
    public partial class tb_Consume_Log
    {
        public string uName { get; set; }

        public int Tnum { get; set; }
        public int Enum { get; set; }
    }
}
