﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBD.Models
{
    public partial class tb_Emp_Hos
    {
        
        //public int Uid { get; set; }

        //public string uName { get; set; }
        //public string DepName { get; set; }
        //public string uLoginName { get; set; }
        //public string KeyWords { get; set; }

        //public string uGender { get; set; }
        //public string uPost { get; set; }
    }
}
